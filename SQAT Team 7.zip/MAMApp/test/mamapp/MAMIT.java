/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package mamapp;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ztjam
 */
public class MAMIT {
    
    public MAMIT() {
    }

    /**
     * Test of getWaterNo method, of class MAM.
     */
    @Test
    public void testGetWaterNo() {
        System.out.println("getWaterNo");
        MAM instance = new MAMImpl();
        Integer expResult = 0;
        Integer result = instance.getWaterNo();
        assertEquals(expResult, result);

    }

    /**
     * Test of setWaterNo method, of class MAM.
     */
    @Test
    public void testSetWaterNo() {
        System.out.println("setWaterNo");
        Integer WaterNo = 0;
        MAM instance = new MAMImpl();
        instance.setWaterNo(WaterNo);
        
    }

    /**
     * Test of getStretchNo method, of class MAM.
     */
    @Test
    public void testGetStretchNo() {
        System.out.println("getStretchNo");
        MAM instance = new MAMImpl();
        Integer expResult = 0;
        Integer result = instance.getStretchNo();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setStretchNo method, of class MAM.
     */
    @Test
    public void testSetStretchNo() {
        System.out.println("setStretchNo");
        Integer StretchNo = 0;
        MAM instance = new MAMImpl();
        instance.setStretchNo(StretchNo);
       
    }

    /**
     * Test of getBreakNo method, of class MAM.
     */
    @Test
    public void testGetBreakNo() {
        System.out.println("getBreakNo");
        MAM instance = new MAMImpl();
        Integer expResult = 0;
        Integer result = instance.getBreakNo();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setBreakNo method, of class MAM.
     */
    @Test
    public void testSetBreakNo() {
        System.out.println("setBreakNo");
        Integer BreakNo = 0;
        MAM instance = new MAMImpl();
        instance.setBreakNo(BreakNo);
       
    }

    /**
     * Test of getCalender1 method, of class MAM.
     */
    @Test
    public void testGetCalender1() {
        System.out.println("getCalender1");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender1();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender1 method, of class MAM.
     */
    @Test
    public void testSetCalender1() {
        System.out.println("setCalender1");
        String Calender1 = "";
        MAM instance = new MAMImpl();
        instance.setCalender1(Calender1);
       
    }

    /**
     * Test of getCalender2 method, of class MAM.
     */
    @Test
    public void testGetCalender2() {
        System.out.println("getCalender2");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender2();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender2 method, of class MAM.
     */
    @Test
    public void testSetCalender2() {
        System.out.println("setCalender2");
        String Calender2 = "";
        MAM instance = new MAMImpl();
        instance.setCalender2(Calender2);
       
    }

    /**
     * Test of getCalender3 method, of class MAM.
     */
    @Test
    public void testGetCalender3() {
        System.out.println("getCalender3");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender3();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setCalender3 method, of class MAM.
     */
    @Test
    public void testSetCalender3() {
        System.out.println("setCalender3");
        String Calender3 = "";
        MAM instance = new MAMImpl();
        instance.setCalender3(Calender3);
       
    }

    /**
     * Test of getCalender4 method, of class MAM.
     */
    @Test
    public void testGetCalender4() {
        System.out.println("getCalender4");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender4();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender4 method, of class MAM.
     */
    @Test
    public void testSetCalender4() {
        System.out.println("setCalender4");
        String Calender4 = "";
        MAM instance = new MAMImpl();
        instance.setCalender4(Calender4);
       
    }

    /**
     * Test of getCalender5 method, of class MAM.
     */
    @Test
    public void testGetCalender5() {
        System.out.println("getCalender5");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender5();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender5 method, of class MAM.
     */
    @Test
    public void testSetCalender5() {
        System.out.println("setCalender5");
        String Calender5 = "";
        MAM instance = new MAMImpl();
        instance.setCalender5(Calender5);
        
    }

    /**
     * Test of getCalender6 method, of class MAM.
     */
    @Test
    public void testGetCalender6() {
        System.out.println("getCalender6");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender6();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender6 method, of class MAM.
     */
    @Test
    public void testSetCalender6() {
        System.out.println("setCalender6");
        String Calender6 = "";
        MAM instance = new MAMImpl();
        instance.setCalender6(Calender6);
        
    }

    /**
     * Test of getCalender7 method, of class MAM.
     */
    @Test
    public void testGetCalender7() {
        System.out.println("getCalender7");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender7();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setCalender7 method, of class MAM.
     */
    @Test
    public void testSetCalender7() {
        System.out.println("setCalender7");
        String Calender7 = "";
        MAM instance = new MAMImpl();
        instance.setCalender7(Calender7);
       
    }

    /**
     * Test of getCalender8 method, of class MAM.
     */
    @Test
    public void testGetCalender8() {
        System.out.println("getCalender8");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender8();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setCalender8 method, of class MAM.
     */
    @Test
    public void testSetCalender8() {
        System.out.println("setCalender8");
        String Calender8 = "";
        MAM instance = new MAMImpl();
        instance.setCalender8(Calender8);
      
    }

    /**
     * Test of getCalender9 method, of class MAM.
     */
    @Test
    public void testGetCalender9() {
        System.out.println("getCalender9");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender9();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setCalender9 method, of class MAM.
     */
    @Test
    public void testSetCalender9() {
        System.out.println("setCalender9");
        String Calender9 = "";
        MAM instance = new MAMImpl();
        instance.setCalender9(Calender9);
        
    }

    /**
     * Test of getCalender10 method, of class MAM.
     */
    @Test
    public void testGetCalender10() {
        System.out.println("getCalender10");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender10();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender10 method, of class MAM.
     */
    @Test
    public void testSetCalender10() {
        System.out.println("setCalender10");
        String Calender10 = "";
        MAM instance = new MAMImpl();
        instance.setCalender10(Calender10);
        
    }

    /**
     * Test of getCalender11 method, of class MAM.
     */
    @Test
    public void testGetCalender11() {
        System.out.println("getCalender11");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender11();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender11 method, of class MAM.
     */
    @Test
    public void testSetCalender11() {
        System.out.println("setCalender11");
        String Calender11 = "";
        MAM instance = new MAMImpl();
        instance.setCalender11(Calender11);
        
    }

    /**
     * Test of getCalender12 method, of class MAM.
     */
    @Test
    public void testGetCalender12() {
        System.out.println("getCalender12");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender12();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender12 method, of class MAM.
     */
    @Test
    public void testSetCalender12() {
        System.out.println("setCalender12");
        String Calender12 = "";
        MAM instance = new MAMImpl();
        instance.setCalender12(Calender12);
       
    }

    /**
     * Test of getCalender13 method, of class MAM.
     */
    @Test
    public void testGetCalender13() {
        System.out.println("getCalender13");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender13();
        assertEquals(expResult, result);
     
    }

    /**
     * Test of setCalender13 method, of class MAM.
     */
    @Test
    public void testSetCalender13() {
        System.out.println("setCalender13");
        String Calender13 = "";
        MAM instance = new MAMImpl();
        instance.setCalender13(Calender13);
       
    }

    /**
     * Test of getCalender14 method, of class MAM.
     */
    @Test
    public void testGetCalender14() {
        System.out.println("getCalender14");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender14();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender14 method, of class MAM.
     */
    @Test
    public void testSetCalender14() {
        System.out.println("setCalender14");
        String Calender14 = "";
        MAM instance = new MAMImpl();
        instance.setCalender14(Calender14);
      
    }

    /**
     * Test of getCalender15 method, of class MAM.
     */
    @Test
    public void testGetCalender15() {
        System.out.println("getCalender15");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender15();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender15 method, of class MAM.
     */
    @Test
    public void testSetCalender15() {
        System.out.println("setCalender15");
        String Calender15 = "";
        MAM instance = new MAMImpl();
        instance.setCalender15(Calender15);
    }

    /**
     * Test of getCalender16 method, of class MAM.
     */
    @Test
    public void testGetCalender16() {
        System.out.println("getCalender16");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender16();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setCalender16 method, of class MAM.
     */
    @Test
    public void testSetCalender16() {
        System.out.println("setCalender16");
        String Calender16 = "";
        MAM instance = new MAMImpl();
        instance.setCalender16(Calender16);
        
    }

    /**
     * Test of getCalender17 method, of class MAM.
     */
    @Test
    public void testGetCalender17() {
        System.out.println("getCalender17");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender17();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender17 method, of class MAM.
     */
    @Test
    public void testSetCalender17() {
        System.out.println("setCalender17");
        String Calender17 = "";
        MAM instance = new MAMImpl();
        instance.setCalender17(Calender17);
       
    }

    /**
     * Test of getCalender18 method, of class MAM.
     */
    @Test
    public void testGetCalender18() {
        System.out.println("getCalender18");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender18();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setCalender18 method, of class MAM.
     */
    @Test
    public void testSetCalender18() {
        System.out.println("setCalender18");
        String Calender18 = "";
        MAM instance = new MAMImpl();
        instance.setCalender18(Calender18);
       
    }

    /**
     * Test of getCalender19 method, of class MAM.
     */
    @Test
    public void testGetCalender19() {
        System.out.println("getCalender19");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender19();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setCalender19 method, of class MAM.
     */
    @Test
    public void testSetCalender19() {
        System.out.println("setCalender19");
        String Calender19 = "";
        MAM instance = new MAMImpl();
        instance.setCalender19(Calender19);
       
    }

    /**
     * Test of getCalender20 method, of class MAM.
     */
    @Test
    public void testGetCalender20() {
        System.out.println("getCalender20");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender20();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender20 method, of class MAM.
     */
    @Test
    public void testSetCalender20() {
        System.out.println("setCalender20");
        String Calender20 = "";
        MAM instance = new MAMImpl();
        instance.setCalender20(Calender20);
        
    }

    /**
     * Test of getCalender21 method, of class MAM.
     */
    @Test
    public void testGetCalender21() {
        System.out.println("getCalender21");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender21();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setCalender21 method, of class MAM.
     */
    @Test
    public void testSetCalender21() {
        System.out.println("setCalender21");
        String Calender21 = "";
        MAM instance = new MAMImpl();
        instance.setCalender21(Calender21);
        
    }

    /**
     * Test of getCalender22 method, of class MAM.
     */
    @Test
    public void testGetCalender22() {
        System.out.println("getCalender22");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender22();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender22 method, of class MAM.
     */
    @Test
    public void testSetCalender22() {
        System.out.println("setCalender22");
        String Calender22 = "";
        MAM instance = new MAMImpl();
        instance.setCalender22(Calender22);
        
    }

    /**
     * Test of getCalender23 method, of class MAM.
     */
    @Test
    public void testGetCalender23() {
        System.out.println("getCalender23");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender23();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender23 method, of class MAM.
     */
    @Test
    public void testSetCalender23() {
        System.out.println("setCalender23");
        String Calender23 = "";
        MAM instance = new MAMImpl();
        instance.setCalender23(Calender23);
      
    }

    /**
     * Test of getCalender24 method, of class MAM.
     */
    @Test
    public void testGetCalender24() {
        System.out.println("getCalender24");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender24();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setCalender24 method, of class MAM.
     */
    @Test
    public void testSetCalender24() {
        System.out.println("setCalender24");
        String Calender24 = "";
        MAM instance = new MAMImpl();
        instance.setCalender24(Calender24);
        
    }

    /**
     * Test of getCalender25 method, of class MAM.
     */
    @Test
    public void testGetCalender25() {
        System.out.println("getCalender25");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender25();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setCalender25 method, of class MAM.
     */
    @Test
    public void testSetCalender25() {
        System.out.println("setCalender25");
        String Calender25 = "";
        MAM instance = new MAMImpl();
        instance.setCalender25(Calender25);
        
    }

    /**
     * Test of getCalender26 method, of class MAM.
     */
    @Test
    public void testGetCalender26() {
        System.out.println("getCalender26");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender26();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setCalender26 method, of class MAM.
     */
    @Test
    public void testSetCalender26() {
        System.out.println("setCalender26");
        String Calender26 = "";
        MAM instance = new MAMImpl();
        instance.setCalender26(Calender26);
        
    }

    /**
     * Test of getCalender27 method, of class MAM.
     */
    @Test
    public void testGetCalender27() {
        System.out.println("getCalender27");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender27();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of setCalender27 method, of class MAM.
     */
    @Test
    public void testSetCalender27() {
        System.out.println("setCalender27");
        String Calender27 = "";
        MAM instance = new MAMImpl();
        instance.setCalender27(Calender27);
        
    }

    /**
     * Test of getCalender28 method, of class MAM.
     */
    @Test
    public void testGetCalender28() {
        System.out.println("getCalender28");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getCalender28();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setCalender28 method, of class MAM.
     */
    @Test
    public void testSetCalender28() {
        System.out.println("setCalender28");
        String Calender28 = "";
        MAM instance = new MAMImpl();
        instance.setCalender28(Calender28);
        
    }

    /**
     * Test of getAdvice method, of class MAM.
     */
    @Test
    public void testGetAdvice() {
        System.out.println("getAdvice");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getAdvice();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setAdvice method, of class MAM.
     */
    @Test
    public void testSetAdvice() {
        System.out.println("setAdvice");
        String Advice = "";
        MAM instance = new MAMImpl();
        instance.setAdvice(Advice);
       
    }

    /**
     * Test of getDetails method, of class MAM.
     */
    @Test
    public void testGetDetails() {
        System.out.println("getDetails");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getDetails();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of getAdvices method, of class MAM.
     */
    @Test
    public void testGetAdvices() {
        System.out.println("getAdvices");
        MAM instance = new MAMImpl();
        String expResult = "";
        String result = instance.getAdvices();
        assertEquals(expResult, result);
        
    }

    public class MAMImpl extends MAM {
    }
    
}
