/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package mamapp;

import java.io.File;
import java.io.IOException;
import static mamapp.MAMGUI.health;
import org.junit.Test;

/**
 *
 * @author ztjam
 */
public class MAMAppIT {
    
    public MAMAppIT() {
    }

    /**
     * Test of main method, of class MAMApp.
     */
    @Test
    public void testMain() {
        
        try{
            
            
       MAMGUI myGUI = new MAMGUI();
        myGUI.setVisible(true);
        
     try {
      File myObj = new File("MAMcalender.txt");
      if (myObj.createNewFile()) {
        System.out.println("File created: " + myObj.getName());
      } else {
        System.out.println("File already exists.");
      }
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
        System.out.println(health);
        
        
        
        }
        catch (Exception e) {
            
        }
    }
    
}
