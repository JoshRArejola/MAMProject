package mamapp;

import java.awt.AWTException;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import org.junit.Test;
import static org.junit.Assert.*;

public class timerTest {
    
    public timerTest() {
    }
    
    

    @Test
    public void testSomeMethod() {
        int newWaterNo=0;
        
         if(newWaterNo == 0){
            SystemTray tray = SystemTray.getSystemTray();
            Image image = Toolkit.getDefaultToolkit().createImage("icon.png");
            TrayIcon trayIcon = new TrayIcon(image, "Tray Demo");
            trayIcon.setImageAutoSize(true);
            trayIcon.setToolTip("System tray icon demo");
             try {
                 tray.add(trayIcon);
             } catch (AWTException ex) {
                 Logger.getLogger(MAMGUI.class.getName()).log(Level.SEVERE, null, ex);
             }

        trayIcon.displayMessage("MAMAPP", "Please Take a Drink of Water", TrayIcon.MessageType.INFO);
        JOptionPane optionPane = new JOptionPane("Please drink some water!",JOptionPane.WARNING_MESSAGE);
            JDialog dialog = optionPane.createDialog("Warning!");
            dialog.setAlwaysOnTop(true); // to show top of all other application
            dialog.setVisible(true);
        }
         else{
             fail("Timer is ticking");
         }
        
    }
    }
