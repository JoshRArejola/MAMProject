/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mamapp;

import java.awt.AWTException;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

/**
 *
 * @author ztjam
 */
public class timer2 extends MAM {
    
    int newBreakNo = 0;
    
    Timer timer2 = new Timer();
    TimerTask task2 = new TimerTask() {
    @Override
    
    public void run() {
        
      
        
        if(newBreakNo >0){
           
             
        newBreakNo--;
        
        System.out.println("Seconds till main break:" + newBreakNo );
        
        MAMGUI.BreakRemaining.setText ( newBreakNo + "Seconds");
        
        
        if (newBreakNo == 0) {
            timer2.cancel();
         timer2.purge();
         
         
           
                    //https://stackoverflow.com/questions/34490218/how-to-make-a-windows-notification-in-java
        //Obtain only one instance of the SystemTray object
        SystemTray tray = SystemTray.getSystemTray();

        //If the icon is a file
        Image image = Toolkit.getDefaultToolkit().createImage("icon.png");
        //Alternative (if the icon is on the classpath):
        //Image image = Toolkit.getDefaultToolkit().createImage(getClass().getResource("icon.png"));

        TrayIcon trayIcon = new TrayIcon(image, "Tray Demo");
        //Let the system resize the image if needed
        trayIcon.setImageAutoSize(true);
        //Set tooltip text for the tray icon
        trayIcon.setToolTip("System tray icon demo");
             try {
                 tray.add(trayIcon);
             } catch (AWTException ex) {
                 Logger.getLogger(MAMGUI.class.getName()).log(Level.SEVERE, null, ex);
             }

        trayIcon.displayMessage("MAMAPP", "Please Take a break", TrayIcon.MessageType.INFO);
         
         
         
         
         
                   JOptionPane optionPane = new JOptionPane("Please take a break!",JOptionPane.WARNING_MESSAGE);
            JDialog dialog = optionPane.createDialog("Warning!");
            dialog.setAlwaysOnTop(true); // to show top of all other application
            dialog.setVisible(true); // to visible the dialog
            
            MAMGUI.EndBreak++;
          
            
            
                }
        }
    }
        
    
    
    };
    
    
    
    
    
    
}
