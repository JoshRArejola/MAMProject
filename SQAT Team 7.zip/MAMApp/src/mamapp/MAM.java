/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mamapp;

/**
 *
 * @author ztjam
 */
public abstract class MAM {
   protected static Integer WaterNo, StretchNo, BreakNo;
   protected String Calender1,Calender2,Calender3,Calender4,Calender5,Calender6,Calender7,Calender8,Calender9,Calender10,Calender11,Calender12,Calender13,Calender14,Calender15,Calender16,Calender17,Calender18,Calender19,Calender20,Calender21,Calender22,Calender23,Calender24,Calender25,Calender26,Calender27,Calender28,Calender29,Calender30,Advice;


public MAM() {
WaterNo = 0;
StretchNo= 0;
BreakNo= 0;
 Calender1 = "";
  Calender2 = "";
  Calender3 = "";
  Calender4 = "";
  Calender5 = "";
  Calender6 = "";
  Calender7 = "";
  Calender8 = "";
  Calender9 = "";
  Calender10 = "";
  Calender11 = "";
  Calender12 = "";
  Calender13 = "";
  Calender14 = "";
  Calender15 = "";
  Calender16 = "";
  Calender17 = "";
  Calender18 = "";
  Calender19 = "";
  Calender20 = "";
  Calender21 = "";
  Calender22 = "";
  Calender23 = "";
  Calender24 = "";
  Calender25 = "";
  Calender26 = "";
  Calender27 = "";
  Calender28 = "";
  Calender29 = "";
  Calender30 = "";
 
 Advice ="";
 

}

    public MAM(Integer WaterNo, Integer StretchNo, Integer BreakNo, String Calender1, String Calender2, String Calender3, String Calender4, String Calender5, String Calender6, String Calender7, String Calender8, String Calender9, String Calender10, String Calender11, String Calender12, String Calender13, String Calender14, String Calender15, String Calender16, String Calender17, String Calender18, String Calender19, String Calender20, String Calender21, String Calender22, String Calender23, String Calender24, String Calender25, String Calender26, String Calender27, String Calender28, String Advice) {
        this.WaterNo = WaterNo;
        this.StretchNo = StretchNo;
        this.BreakNo = BreakNo;
        this.Calender1 = Calender1;
        this.Calender2 = Calender2;
        this.Calender3 = Calender3;
        this.Calender4 = Calender4;
        this.Calender5 = Calender5;
        this.Calender6 = Calender6;
        this.Calender7 = Calender7;
        this.Calender8 = Calender8;
        this.Calender9 = Calender9;
        this.Calender10 = Calender10;
        this.Calender11 = Calender11;
        this.Calender12 = Calender12;
        this.Calender13 = Calender13;
        this.Calender14 = Calender14;
        this.Calender15 = Calender15;
        this.Calender16 = Calender16;
        this.Calender17 = Calender17;
        this.Calender18 = Calender18;
        this.Calender19 = Calender19;
        this.Calender20 = Calender20;
        this.Calender21 = Calender21;
        this.Calender22 = Calender22;
        this.Calender23 = Calender23;
        this.Calender24 = Calender24;
        this.Calender25 = Calender25;
        this.Calender26 = Calender26;
        this.Calender27 = Calender27;
        this.Calender28 = Calender28;
        this.Calender29 = Calender27;
        this.Calender30 = Calender28;        
        this.Advice = Advice;
    }

    public String getCalender29() {
        return Calender29;
    }

    public void setCalender29(String Calender29) {
        this.Calender29 = Calender29;
    }

    public String getCalender30() {
        return Calender30;
    }

    public void setCalender30(String Calender30) {
        this.Calender30 = Calender30;
    }





    public Integer getWaterNo() {
        return WaterNo;
    }

    public void setWaterNo(Integer WaterNo) {
        this.WaterNo = WaterNo;
    }

    public Integer getStretchNo() {
        return StretchNo;
    }

    public void setStretchNo(Integer StretchNo) {
        this.StretchNo = StretchNo;
    }

    public Integer getBreakNo() {
        return BreakNo;
    }

    public void setBreakNo(Integer BreakNo) {
        this.BreakNo = BreakNo;
    }

    public String getCalender1() {
        return Calender1;
    }

    public void setCalender1(String Calender1) {
        this.Calender1 = Calender1;
    }

    public String getCalender2() {
        return Calender2;
    }

    public void setCalender2(String Calender2) {
        this.Calender2 = Calender2;
    }

    public String getCalender3() {
        return Calender3;
    }

    public void setCalender3(String Calender3) {
        this.Calender3 = Calender3;
    }

    public String getCalender4() {
        return Calender4;
    }

    public void setCalender4(String Calender4) {
        this.Calender4 = Calender4;
    }

    public String getCalender5() {
        return Calender5;
    }

    public void setCalender5(String Calender5) {
        this.Calender5 = Calender5;
    }

    public String getCalender6() {
        return Calender6;
    }

    public void setCalender6(String Calender6) {
        this.Calender6 = Calender6;
    }

    public String getCalender7() {
        return Calender7;
    }

    public void setCalender7(String Calender7) {
        this.Calender7 = Calender7;
    }

    public String getCalender8() {
        return Calender8;
    }

    public void setCalender8(String Calender8) {
        this.Calender8 = Calender8;
    }

    public String getCalender9() {
        return Calender9;
    }

    public void setCalender9(String Calender9) {
        this.Calender9 = Calender9;
    }

    public String getCalender10() {
        return Calender10;
    }

    public void setCalender10(String Calender10) {
        this.Calender10 = Calender10;
    }

    public String getCalender11() {
        return Calender11;
    }

    public void setCalender11(String Calender11) {
        this.Calender11 = Calender11;
    }

    public String getCalender12() {
        return Calender12;
    }

    public void setCalender12(String Calender12) {
        this.Calender12 = Calender12;
    }

    public String getCalender13() {
        return Calender13;
    }

    public void setCalender13(String Calender13) {
        this.Calender13 = Calender13;
    }

    public String getCalender14() {
        return Calender14;
    }

    public void setCalender14(String Calender14) {
        this.Calender14 = Calender14;
    }

    public String getCalender15() {
        return Calender15;
    }

    public void setCalender15(String Calender15) {
        this.Calender15 = Calender15;
    }

    public String getCalender16() {
        return Calender16;
    }

    public void setCalender16(String Calender16) {
        this.Calender16 = Calender16;
    }

    public String getCalender17() {
        return Calender17;
    }

    public void setCalender17(String Calender17) {
        this.Calender17 = Calender17;
    }

    public String getCalender18() {
        return Calender18;
    }

    public void setCalender18(String Calender18) {
        this.Calender18 = Calender18;
    }

    public String getCalender19() {
        return Calender19;
    }

    public void setCalender19(String Calender19) {
        this.Calender19 = Calender19;
    }

    public String getCalender20() {
        return Calender20;
    }

    public void setCalender20(String Calender20) {
        this.Calender20 = Calender20;
    }

    public String getCalender21() {
        return Calender21;
    }

    public void setCalender21(String Calender21) {
        this.Calender21 = Calender21;
    }

    public String getCalender22() {
        return Calender22;
    }

    public void setCalender22(String Calender22) {
        this.Calender22 = Calender22;
    }

    public String getCalender23() {
        return Calender23;
    }

    public void setCalender23(String Calender23) {
        this.Calender23 = Calender23;
    }

    public String getCalender24() {
        return Calender24;
    }

    public void setCalender24(String Calender24) {
        this.Calender24 = Calender24;
    }

    public String getCalender25() {
        return Calender25;
    }

    public void setCalender25(String Calender25) {
        this.Calender25 = Calender25;
    }

    public String getCalender26() {
        return Calender26;
    }

    public void setCalender26(String Calender26) {
        this.Calender26 = Calender26;
    }

    public String getCalender27() {
        return Calender27;
    }

    public void setCalender27(String Calender27) {
        this.Calender27 = Calender27;
    }

    public String getCalender28() {
        return Calender28;
    }

    public void setCalender28(String Calender28) {
        this.Calender28 = Calender28;
    }

   

    public String getAdvice() {
        return Advice;
    }

    public void setAdvice(String Advice) {
        this.Advice = Advice;
    }
    
    

  

public String getDetails(){
        return "\n"+Calender1+"\n"+Calender2+"\n"+Calender3+"\n"+ Calender4 + "\n" + Calender5 +"\n"+Calender6+"\n"+Calender7+"\n"+Calender8+"\n"+Calender9+"\n"+Calender10+"\n"+Calender11+"\n"+Calender12+"\n"+Calender13+"\n"+Calender14+"\n"+Calender15+"\n"+Calender16+"\n"+ Calender17 +"\n"+Calender18+"\n"+Calender19+"\n"+Calender20+"\n"+Calender21+"\n"+Calender22+"\n"+Calender23+"\n"+Calender24+"\n"+Calender25+"\n"+Calender26+"\n"+Calender27+"\n"+Calender28+"\n"+Calender29+"\n"+Calender30+"\n";
    }

public String getAdvices(){
        return Advice;
    }






}