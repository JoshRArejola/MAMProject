/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mamapp;

/**
 *
 * @author ztjam
 */
public class Calender extends MAM{
    
    public Calender(){
        super();
     
    }
    
     public Calender (Integer WaterNo, Integer StretchNo, Integer BreakNo, String Calender1, String Calender2, String Calender3, String Calender4, String Calender5, String Calender6, String Calender7, String Calender8, String Calender9, String Calender10, String Calender11, String Calender12, String Calender13, String Calender14, String Calender15, String Calender16, String Calender17, String Calender18, String Calender19, String Calender20, String Calender21, String Calender22, String Calender23, String Calender24, String Calender25, String Calender26, String Calender27, String Calender28, String Advice){
        
        super();
        
    }
    
     
      @Override 
    public String getDetails() {
        return super.getDetails();
    }
    
}
