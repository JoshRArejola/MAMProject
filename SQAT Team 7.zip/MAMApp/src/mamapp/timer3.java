/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mamapp;

import java.awt.AWTException;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

/**
 *
 * @author ztjam
 */
public class timer3 extends MAM {
    
    int newStretchNo = 0;
    
    Timer timer3 = new Timer();
    TimerTask task3 = new TimerTask() {
    @Override
    
    public void run() {
        
      
        
        if(newStretchNo >0){
           
             
        newStretchNo--;
        
        System.out.println("Seconds till stretch:" + newStretchNo );
        
        MAMGUI.StretchRemaining.setText ( newStretchNo + "Seconds");
        
        
        if (newStretchNo == 0) {
            timer3.cancel();
         timer3.purge();
         
         
                     //https://stackoverflow.com/questions/34490218/how-to-make-a-windows-notification-in-java
        //Obtain only one instance of the SystemTray object
        SystemTray tray = SystemTray.getSystemTray();

        //If the icon is a file
        Image image = Toolkit.getDefaultToolkit().createImage("icon.png");
        //Alternative (if the icon is on the classpath):
        //Image image = Toolkit.getDefaultToolkit().createImage(getClass().getResource("icon.png"));

        TrayIcon trayIcon = new TrayIcon(image, "Tray Demo");
        //Let the system resize the image if needed
        trayIcon.setImageAutoSize(true);
        //Set tooltip text for the tray icon
        trayIcon.setToolTip("System tray icon demo");
             try {
                 tray.add(trayIcon);
             } catch (AWTException ex) {
                 Logger.getLogger(MAMGUI.class.getName()).log(Level.SEVERE, null, ex);
             }

        trayIcon.displayMessage("MAMAPP", "Please have a stretch", TrayIcon.MessageType.INFO);
         
         
         
                   JOptionPane optionPane = new JOptionPane("Please take a stretch!",JOptionPane.WARNING_MESSAGE);
            JDialog dialog = optionPane.createDialog("Warning!");
            dialog.setAlwaysOnTop(true); // to show top of all other application
            dialog.setVisible(true); // to visible the dialog
            
        MAMGUI.EndStretch++;
            
                }
        }
    }
        
    
    
    };
    
    
    
    
    
    
}